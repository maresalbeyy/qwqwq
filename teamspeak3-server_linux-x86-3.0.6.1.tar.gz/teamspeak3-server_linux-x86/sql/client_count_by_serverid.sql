select count(*) as count from clients where server_id=:server_id:;
